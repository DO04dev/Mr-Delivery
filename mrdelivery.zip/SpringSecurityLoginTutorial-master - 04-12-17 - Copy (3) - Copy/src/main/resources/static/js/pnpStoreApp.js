var pnpModule = angular.module("pnpStoreApp",[]);


pnpModule.controller("pnpStoreAppController",function($scope,$http){
	   
    $http.defaults.headers.post["Content-Type"] = "application/json";  
    
	//Get all StockOrder in database
	$http.get('/GetStockOrders').then(function(response){
	console.log(response.data);
	$scope.restaurants = response.data; 	
	});
	
	
     
});



