var mrdApp = angular.module('mrdApp', []);



mrdApp.controller('MrdAppController', function ($scope, $http)
{
    $scope.prodLength= [];
    
    $http.defaults.headers.post["Content-Type"] = "application/json";

    $scope.menForm = {itemtName: ""};

    /**$scope.newRestaurant = function (){
     $http.post(url, {
     restaurantName: $scope.restaurantForm.restaurantName,
     restaurantEmail: $scope.restaurantForm.restaurantEmail,
     restaurantTel: $scope.restaurantForm.restaurantTel,
     restaurantAddressline: $scope.restaurantForm.restaurantAddressline,
     restaurantZip: $scope.restaurantForm.restaurantZip,
     }).then(successCallback, errorCallback);
     
     function successCallback(response){
     alert("added");
     console.log(response.data);
     $location.url('http://localhost:8080/SaveRestaurant')
     }
     function errorCallback(response){
     console.log(response);
     alert("failed");
     }
     };**/

    $scope.newRestaurants = function ()
    {
        console.log("restaurant");

        var resForm = {
            restaurantName: $scope.restaurantForm.restaurantName,
            restaurantEmail: $scope.restaurantForm.restaurantEmail,
            restaurantTel: $scope.restaurantForm.restaurantTel,
            restaurantAddressline: $scope.restaurantForm.restaurantAddressline,
            restaurantZip: $scope.restaurantForm.restaurantZip,
        };
        console.log(resForm);
        $http({
            method: 'POST',
            url: 'http://localhost:8080/SaveRestaurant',
            data: angular.toJson(resForm),
            headers: {'Content-Type': 'application/json'}
        })
                .success(function (data) {
                    $scope.MrdAppController = data;
                    alert("New Restaurant Added");
                    location.reload(true);
                });
    };

    $scope.newMenus = function ()
    {
        console.log("Menu");

        var menuForm = {
            itemName: $scope.menForm.itemtName,
            price: $scope.menForm.price,
            description: $scope.menForm.description,
            image: "$scope.menForm.image"
        };
        console.log(menuForm);
        $http({
            method: 'POST',
            url: 'http://localhost:8080/SaveMenu',
            data: angular.toJson(menuForm),
            headers: {'Content-Type': 'application/json'}
        })
                .success(function (data) {
                    $scope.MrdAppController = data;
                    alert("New Menu Added");
                    location.reload(true);
                });
    };

    $scope.menuItem;

    $scope.adminViewMenu = function (restaurant)
    {
        var restaurants = [];
        $scope.prodLength[0] = restaurant.restaurant_id;
        console.log(restaurant.restaurant_id);
        $http({
            method: 'GET',
            url: 'http://localhost:8080/admin/home/' + restaurant.restaurant_id,
            data: angular.fromJson(restaurants),
            headers: {'Content-Type': 'application/json'}
        })
                .success(function (data) {
                    $scope.Items = data;
                    console.log($scope.Items);
                });
        console.log($scope.prodLength[0]);
        $("myModal").modal("show");
    };

    retreiveRestaurants();
    var availableRestaurants;
    function retreiveRestaurants() {
        $http({
            method: 'GET',
            url: 'http://localhost:8080/GetRestaurants',
            data: angular.fromJson(availableRestaurants),
            headers: {'Content-Type': 'application/json'}
        })
                .success(function (data) {
                    $scope.availableRestaurants = data;

                });
    }

    retrieveMenus();
    var availableMenus;
    function retrieveMenus() {
        $http({
            method: 'GET',
            url: 'http://localhost:8080/GetMenus',
            data: angular.fromJson(availableMenus),
            headers: {'Content-Type': 'application/json'}
        })
                .success(function (data) {
                    $scope.availableMenus = data;

                });
    }

    $scope.editRestaurant = function (restaurant) {
        var updateRestaurant = {
            restaurantId: restaurant.restaurantId
        };

        console.log(updateRestaurant);

        $http({
            method: 'PUT',
            url: 'http://localhost:8080/updateRestaurant/' + restaurant.restaurantId,
            data: angular.toJson(updateRestaurant),
            headers: {'Content-Type': 'application/json'}
        })
                .success(function (data) {
                    $scope.MrdAppController = data;
                    alert("Restaurant Updated");
                    retreiveRestaurants();
                });
    };

    $scope.removeRestaurant = function (restaurant) {
        var wipeRestaurant = {
            restaurantId: restaurant.restaurantId
        };

        console.log(wipeRestaurant);

        $http({
            method: 'DELETE',
            url: 'http://localhost:8080/DeleteRestaurant/' + restaurant.restaurantId,
            data: angular.toJson(wipeRestaurant),
            headers: {'Content-Type': 'application/json'}
        })
                .success(function (data) {
                    $scope.MrdAppController = data;
                    alert("Restaurant Removed");
                    retreiveRestaurants();
                });
    };

    //Retrieve all Locations 
    $http.get('/GetLocations').then(function (response) {
        $scope.locations = response.data;
        console.log(response.data);
    });
    //Retrieve all Restaurants
    $http.get('/GetRestaurants').then(function (response) {
        console.log(response.data);
        $scope.restaurants = response.data;
    });
    //Retrieve menus
    $http.get('/GetMenus').then(function (response) {
        console.log(response.data);
        $scope.products = response.data;
    });




});
