package com.example.service;

import com.example.model.Menu;
import com.example.repository.MenuRepository;
import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author User
 */
@Service
public class MenuService {
    //@Autowired - uses properties to get rid of setter methods 

    @Autowired
    private MenuRepository menuRepository;

    public List<Menu> getAllmenus() {

        List<Menu> menus = new ArrayList<>();
        menuRepository.findAll()
                .forEach(menus::add);
        return menus;

    }

    //delete Product
    public void DeleteMenu(int menuID) {

        menuRepository.delete(menuID);

    }

    //Add Product
    public void menuForm(Menu menu) {
        menuRepository.save(menu);
    }

    //update Product using product id
    public void updateMenu(int id, Menu menu) {

        menuRepository.save(menu);

    }
}
