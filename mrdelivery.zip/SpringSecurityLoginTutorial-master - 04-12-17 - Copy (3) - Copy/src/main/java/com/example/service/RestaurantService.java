package com.example.service;

import com.example.model.Restaurant;
import com.example.repository.RestaurantRepository;
import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class RestaurantService {
    //@Autowired - uses properties to get rid of setter methods 

    @Autowired
    private RestaurantRepository restaurantRepository;

    public List<Restaurant> getAllrestaurants() {

        List<Restaurant> restaurants = new ArrayList<>();
        restaurantRepository.findAll()
                .forEach(restaurants::add);
        return restaurants;

    }

    //delete Product
    public void DeleteRestaurant(int restaurantID) {

        restaurantRepository.delete(restaurantID);

    }

    //Add Product
    public void resForm(Restaurant restaurant) {
        restaurantRepository.save(restaurant);
    }

    //update Product using product id
    public void updateRestaurant(int id, Restaurant restaurant) {

        restaurantRepository.save(restaurant);

    }

}
