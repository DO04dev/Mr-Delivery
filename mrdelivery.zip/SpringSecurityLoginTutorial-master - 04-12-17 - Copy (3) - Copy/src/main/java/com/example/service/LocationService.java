/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.service;

import com.example.model.Location;

import com.example.repository.LocationRepository;
import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author User
 */

@Service
public class LocationService {
    @Autowired
    private LocationRepository locationRepository;
    
    public List<Location> getAllLocations(){
        List<Location> location = new ArrayList<>();
		locationRepository.findAll()
		.forEach(location::add);
		return location;
    }

    public void DeleteLocation(int locationId) {
        locationRepository.delete(locationId);
    }

    public void saveLocation(Location Locations) {
        locationRepository.save(Locations);
    }

    public void UpdateLocation(int locId, Location Locations) {
        locationRepository.save(Locations);
    }
}
