package com.example.model;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author User
 */
@Entity
@Table(name = "restaurant")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Restaurant.findAll", query = "SELECT r FROM Restaurant r")
    , @NamedQuery(name = "Restaurant.findByRestaurantId", query = "SELECT r FROM Restaurant r WHERE r.restaurantId = :restaurantId")
    , @NamedQuery(name = "Restaurant.findByRestaurantName", query = "SELECT r FROM Restaurant r WHERE r.restaurantName = :restaurantName")
    , @NamedQuery(name = "Restaurant.findByRestaurantEmail", query = "SELECT r FROM Restaurant r WHERE r.restaurantEmail = :restaurantEmail")
    , @NamedQuery(name = "Restaurant.findByRestaurantTel", query = "SELECT r FROM Restaurant r WHERE r.restaurantTel = :restaurantTel")
    , @NamedQuery(name = "Restaurant.findByRestaurantAddressline", query = "SELECT r FROM Restaurant r WHERE r.restaurantAddressline = :restaurantAddressline")
    , @NamedQuery(name = "Restaurant.findByRestaurantZip", query = "SELECT r FROM Restaurant r WHERE r.restaurantZip = :restaurantZip")})
public class Restaurant implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "restaurant_id")
    private Integer restaurantId;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 255)
    @Column(name = "restaurant_name")
    private String restaurantName;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 255)
    @Column(name = "restaurant_email")
    private String restaurantEmail;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 255)
    @Column(name = "restaurant_tel")
    private String restaurantTel;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 255)
    @Column(name = "restaurant_addressline")
    private String restaurantAddressline;
    @Basic(optional = false)
    @NotNull
    @Column(name = "restaurant_zip")
    private int restaurantZip;
   

    public Restaurant() {
    }

    public Restaurant(Integer restaurantId) {
        this.restaurantId = restaurantId;
    }

    public Restaurant(Integer restaurantId, String restaurantName, String restaurantEmail, String restaurantTel, String restaurantAddressline, int restaurantZip) {
        this.restaurantId = restaurantId;
        this.restaurantName = restaurantName;
        this.restaurantEmail = restaurantEmail;
        this.restaurantTel = restaurantTel;
        this.restaurantAddressline = restaurantAddressline;
        this.restaurantZip = restaurantZip;
        }

    public Integer getRestaurantId() {
        return restaurantId;
    }

    public void setRestaurantId(Integer restaurantId) {
        this.restaurantId = restaurantId;
    }
    
    public String getRestaurantName() {
        return restaurantName;
    }

    public void setRestaurantName(String restaurantName) {
        this.restaurantName = restaurantName;
    }

    public String getRestaurantEmail() {
        return restaurantEmail;
    }

    public void setRestaurantEmail(String restaurantEmail) {
        this.restaurantEmail = restaurantEmail;
    }

    public String getRestaurantTel() {
        return restaurantTel;
    }

    public void setRestaurantTel(String restaurantTel) {
        this.restaurantTel = restaurantTel;
    }

    public String getRestaurantAddressline() {
        return restaurantAddressline;
    }

    public void setRestaurantAddressline(String restaurantAddressline) {
        this.restaurantAddressline = restaurantAddressline;
    }

    public int getRestaurantZip() {
        return restaurantZip;
    }

    public void setRestaurantZip(int restaurantZip) {
        this.restaurantZip = restaurantZip;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (restaurantId != null ? restaurantId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Restaurant)) {
            return false;
        }
        Restaurant other = (Restaurant) object;
        if ((this.restaurantId == null && other.restaurantId != null) || (this.restaurantId != null && !this.restaurantId.equals(other.restaurantId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.example.model.Restaurant[ restaurantId=" + restaurantId + " ]";
    }
    
}
