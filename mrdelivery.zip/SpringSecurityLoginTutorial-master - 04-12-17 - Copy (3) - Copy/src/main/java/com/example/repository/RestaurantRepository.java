package com.example.repository;

import com.example.model.Restaurant;
import java.util.ArrayList;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface RestaurantRepository extends CrudRepository <Restaurant, Integer>  {
    
}
