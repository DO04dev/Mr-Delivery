package com.example.repository;

import com.example.model.Location;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

/**
 *
 * @author User
 */
@Repository
public interface LocationRepository extends CrudRepository<Location, Integer> {
    
}
