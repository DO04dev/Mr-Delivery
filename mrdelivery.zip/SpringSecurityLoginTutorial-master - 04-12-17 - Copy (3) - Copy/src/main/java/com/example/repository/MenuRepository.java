package com.example.repository;

import com.example.model.Menu;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

/**
 *
 * @author User
 */
@Repository
public interface MenuRepository extends CrudRepository <Menu, Integer>  {
    
}
