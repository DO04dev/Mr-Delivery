package com.example.controller;

import com.example.model.Menu;
import com.example.service.MenuService;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author User
 */
@RestController 
public class MenuController {
  
    //@Autowired - uses properties to get rid of setter methods
    @Autowired
   private MenuService menuService;
  
          
    
  //RequestMapping - maps the specified URL eg '/GetProducts'
	@RequestMapping("/GetMenus")
	//Generic array list
	public List<Menu> getAllmenus() 
	{
		return menuService.getAllmenus();
	}
	
	//RequestMapping - maps the specified URL eg '/DeleteProduct/{productID}'
	//RequestMethod = request method type - DELETE it removes specific resources using a certain ID
	@RequestMapping(method = RequestMethod.DELETE,value = "/DeleteMenu/{menuId}")
	//@PathVariable - identifies the path pattern used in URL for incoming data
	public void DeleteMenu(@PathVariable int menuID)
	{
		menuService.DeleteMenu(menuID);
	}
	
	//RequestMapping - maps the specified URL eg '/SaveProduct'
	//RequestMethod = request method type - POST it inserts specific resources
        //@RequestBody converts JSON format to java object
	@RequestMapping(method = RequestMethod.POST,value = "/SaveMenu")
	public void menuForm(@RequestBody Menu menu)
	{
		menuService.menuForm(menu);	
                
	}
	
	//RequestMapping - maps the specified URL eg '/UpdateProduct/{id}'
	//RequestMethod = request method type - PUT it updates specific resources using a certain ID
	@RequestMapping(method = RequestMethod.PUT,value = "/UpdateMenu/{menuId}")
	//@RequestBody converts JSON format to java object
	//@PathVariable - identifies the path pattern used in URL for incoming data
	public void updateMenu(@RequestBody Menu Menus, @PathVariable int id)
	{
		
		menuService.updateMenu(id, Menus);
		
	}  
}
