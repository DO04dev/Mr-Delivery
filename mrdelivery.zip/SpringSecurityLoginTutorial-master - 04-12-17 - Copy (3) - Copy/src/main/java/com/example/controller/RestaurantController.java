
package com.example.controller;

import com.example.model.Restaurant;
import com.example.service.RestaurantService;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;


//@RestController - indicates that it is a  Spring MVC controller using REST API


@RestController 
public class RestaurantController {
  
    //@Autowired - uses properties to get rid of setter methods
    @Autowired
   private RestaurantService restaurantService;
  
          
    
  //RequestMapping - maps the specified URL eg '/GetProducts'
	@RequestMapping("/GetRestaurants")
	//Generic array list
	public List<Restaurant> getAllrestaurants() 
	{
		return restaurantService.getAllrestaurants();
	}
	
	//RequestMapping - maps the specified URL eg '/DeleteProduct/{productID}'
	//RequestMethod = request method type - DELETE it removes specific resources using a certain ID
	@RequestMapping(method = RequestMethod.DELETE,value = "/DeleteRestaurant/{restaurantId}")
	//@PathVariable - identifies the path pattern used in URL for incoming data
	public void DeleteRestaurant(@PathVariable int restaurantID)
	{
		restaurantService.DeleteRestaurant(restaurantID);
	}
	
	//RequestMapping - maps the specified URL eg '/SaveProduct'
	//RequestMethod = request method type - POST it inserts specific resources
        //@RequestBody converts JSON format to java object
	@RequestMapping(method = RequestMethod.POST,value = "/SaveRestaurant")
	public void resForm(@RequestBody Restaurant restaurant)
	{
		restaurantService.resForm(restaurant);	
                
	}
	
	//RequestMapping - maps the specified URL eg '/UpdateProduct/{id}'
	//RequestMethod = request method type - PUT it updates specific resources using a certain ID
	@RequestMapping(method = RequestMethod.PUT,value = "/UpdateRestaurant/{restaurantId}")
	//@RequestBody converts JSON format to java object
	//@PathVariable - identifies the path pattern used in URL for incoming data
	public void updateRestaurant(@RequestBody Restaurant Restaurants, @PathVariable int id)
	{
		
		restaurantService.updateRestaurant(id, Restaurants);
		
	}  
    
}
