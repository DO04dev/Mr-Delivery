package com.example.controller;

import com.example.model.Location;
import com.example.repository.LocationRepository;
import com.example.service.LocationService;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author Thabo
 */
@RestController
public class LocationController {

    @Autowired
    private LocationService locationService;

    @RequestMapping("/GetLocations")
    public List<Location> getAllLocations() {
        return locationService.getAllLocations();
    }

    @RequestMapping(method = RequestMethod.DELETE, value = "/DeleteLocation/{locationId}")
    public void DeleteLocation(@PathVariable int locationId) {
        locationService.DeleteLocation(locationId);
    }

    @RequestMapping(method = RequestMethod.POST, value = "/SaveLocation")
    public void saveLocation(@RequestBody Location Locations) {
        locationService.saveLocation(Locations);
    }

    @RequestMapping(method = RequestMethod.PUT, value = "/UpdateLocation/{locationId}")
    public void UpdateLocation(@RequestBody Location Locations, @PathVariable int locId) {

        locationService.UpdateLocation(locId, Locations);

    }

}


